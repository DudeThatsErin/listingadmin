<?php
require("header.php");
# -----------------------------------------------------------
require("jac.inc.php");
# -----------------------------------------------------------
require(STPATH . "show-kim-stats.php");
# -----------------------------------------------------------
?>
    <ol>
        <li><a href="kim-list.php">List</a></li>
        <li><a href="kim-join.php">Join</a></li>
        <li><a href="kim-reset.php">Reset password</a></li>
        <li><a href="kim-update.php">Update</a></li>
    </ol>
<?php
# -----------------------------------------------------------
require("footer.php");

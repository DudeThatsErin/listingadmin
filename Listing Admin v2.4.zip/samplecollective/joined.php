<?php
require("header.php");
# -----------------------------------------------------------
require("jac.inc.php");
$list = 'n';
$show_lister = 'y';
$show_search = 'y';
# -----------------------------------------------------------
require(STPATH . "show-joined.php");
# -----------------------------------------------------------
require("footer.php");

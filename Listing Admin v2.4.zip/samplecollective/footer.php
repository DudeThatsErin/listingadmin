</section>

<footer>
 <p><strong>&copy; 2023 Dude That's Erin's Collective</strong> </p>
</footer>

</div>

</body>
</html>

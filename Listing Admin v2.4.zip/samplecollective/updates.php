<?php
require("header.php");
# -----------------------------------------------------------
require("jac.inc.php");

$fKey = 0;
$pagination = 3;
$show_all = 'y';
# -----------------------------------------------------------
require(STPATH . "show-updates.php");
# -----------------------------------------------------------
require("footer.php");

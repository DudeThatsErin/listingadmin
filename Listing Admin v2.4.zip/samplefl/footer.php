</section>

<footer>
 <p><strong>Example</strong> &#169; <?php $fanlisting->isYear('2007'); ?></p>
</footer>

</div>

</body>
</html>
